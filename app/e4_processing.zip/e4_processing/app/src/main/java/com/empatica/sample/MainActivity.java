package com.empatica.sample;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.empatica.empalink.ConnectionNotAllowedException;
import com.empatica.empalink.EmpaDeviceManager;
import com.empatica.empalink.EmpaticaDevice;
import com.empatica.empalink.config.EmpaSensorStatus;
import com.empatica.empalink.config.EmpaSensorType;
import com.empatica.empalink.config.EmpaStatus;
import com.empatica.empalink.delegate.EmpaDataDelegate;
import com.empatica.empalink.delegate.EmpaStatusDelegate;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


public class MainActivity extends AppCompatActivity implements EmpaDataDelegate, EmpaStatusDelegate {

    private static final int REQUEST_ENABLE_BT = 1;

    private static final int REQUEST_PERMISSION_ACCESS_COARSE_LOCATION = 1;


    private static final String EMPATICA_API_KEY = "5f429705b8044d8b80090c5c4759d4f1";

    // initialize relaevant views etc
    private Button BGButton;
    private GraphView graph;
    private RequestQueue mQueue;
    private TextView testView;
    private TextView PredictionValue;
    private TextView hypoInd;

    // for graphing
    LineGraphSeries<DataPoint> predictedBG = new LineGraphSeries<>();
    LineGraphSeries<DataPoint> measuredBG = new LineGraphSeries<>();

    private EmpaDeviceManager deviceManager = null;
    private TextView accel_xLabel;
    private TextView accel_yLabel;
    private TextView accel_zLabel;
    private TextView bvpLabel;
    private TextView edaLabel;
    private TextView ibiLabel;
    private TextView temperatureLabel;
    private TextView batteryLabel;
    private TextView statusLabel;
    private TextView deviceNameLabel;
    private LinearLayout dataCnt;

    private int mn = 0;

    // for processing e4 data
    int tracker_raw = 0;
    float[] edas_raw = new float[30];
    float[] hrs_raw = new float[30];
    float[] accs_raw = new float[30];
    float[] temps_raw = new float[30];

    int tracker_avg = 0;
    float[] edas_avg = new float[288];
    float[] hrs_avg = new float[288];
    float[] accs_avg = new float[288];
    float[] temps_avg = new float[288];

    float[] cgm_feats = new float[4];
    float[] eda_feats = new float[4];
    float[] temp_feats = new float[4];
    float[] acc_feats = new float[6];
    float[] hr_feats = new float[7];


    int e4_connected = 0;

    long timer;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION_ACCESS_COARSE_LOCATION:
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted, yay!
                    initEmpaticaDeviceManager();
                } else {
                    // Permission denied, boo!
                    final boolean needRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION);
                    new AlertDialog.Builder(this)
                            .setTitle("Permission required")
                            .setMessage("Without this permission bluetooth low energy devices cannot be found, allow it in order to connect to the device.")
                            .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // try again
                                    if (needRationale) {
                                        // the "never ask again" flash is not set, try again with permission request
                                        initEmpaticaDeviceManager();
                                    } else {
                                        // the "never ask again" flag is set so the permission requests is disabled, try open app settings to enable the permission
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                                        intent.setData(uri);
                                        startActivity(intent);
                                    }
                                }
                            })
                            .setNegativeButton("Exit application", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // without permission exit is the only way
                                    finish();
                                }
                            })
                            .show();
                }
                break;
        }
    }


    // main stuff happening here
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);



        // initialize requestQueue with context;
        mQueue = Volley.newRequestQueue(this);

        // Initialize vars that reference UI components
        statusLabel = (TextView) findViewById(R.id.status);
        dataCnt = (LinearLayout) findViewById(R.id.dataArea);
        accel_xLabel = (TextView) findViewById(R.id.accel_x);
        accel_yLabel = (TextView) findViewById(R.id.accel_y);
        accel_zLabel = (TextView) findViewById(R.id.accel_z);
        bvpLabel = (TextView) findViewById(R.id.bvp);
        edaLabel = (TextView) findViewById(R.id.eda);
        ibiLabel = (TextView) findViewById(R.id.ibi);
        temperatureLabel = (TextView) findViewById(R.id.temperature);
        batteryLabel = (TextView) findViewById(R.id.battery);
        deviceNameLabel = (TextView) findViewById(R.id.deviceName);
        // setup testview for holding values
        testView = findViewById(R.id.testView);

        // create notification channel if required by current android version
        String CHANNEL_ID = "IMPENDING LOWS";
        createNotificationChannel(CHANNEL_ID);
        String warningTitle = "Impending Low Blood Glucose Alert";
        String warningText = "Low BG predicted, treat appropriately";

        final NotificationCompat.Builder nBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.down_arrow)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.low_icon))
                .setContentTitle(warningTitle)
                .setContentText(warningText)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        final NotificationManagerCompat nManager  = NotificationManagerCompat.from(this);

        // go to the settings page
        Button SettingsBtn = (Button) findViewById(R.id.Settings);
        SettingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToSettings = new Intent(getApplicationContext(), com.empatica.sample.SettingsActivity.class);
                startActivity(GoToSettings);
            }
        });

        // BG test button used for function testing
        BGButton = (Button) findViewById(R.id.BGButton);
        BGButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nManager.notify(0, nBuilder.build());
            }
        });

        Button RegisterBtn = (Button) findViewById(R.id.RegisterBtn);
        RegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Authorization step
                // uri for authorization using my client ID
                String authAddress = "https://api.dexcom.com/v2/oauth2/login?client_id=ENwGnmMXfud5MPyUxJ19yR23DtBIQ3ZO&redirect_uri=https://www.google.com&response_type=code&scope=offline_access";
                Uri authAddressUri = Uri.parse(authAddress);

                // send user to the registration address
                Intent RegisterUser = new Intent(Intent.ACTION_VIEW, authAddressUri);
                if (RegisterUser.resolveActivity(getPackageManager()) != null) {
                    startActivity(RegisterUser);
                }

            }

        });

        // disconnect
        final Button disconnectButton = findViewById(R.id.disconnectButton);
        disconnectButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (deviceManager != null) {

                    deviceManager.disconnect();
                }
            }
        });

        initEmpaticaDeviceManager();

        ////// graph stuff

        // get graph content
        graph = (GraphView) findViewById(R.id.BGGraph);
        // set graph properties
        graph.setTitle("Your Blood Glucose"); // title
        graph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.NONE);

        //set x bounds
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(-180);
        graph.getViewport().setMaxX(30);
        //set  y bounds
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinY(30);
        graph.getViewport().setMaxY(400);

        // adapted from graphview documentation at https://github.com/jjoe64/GraphView/wiki/Simple-graph
        // adds boundary lines to the graphview for hypo and hyperglycemia

        // hypo threshold
        LineGraphSeries<DataPoint> lowThresh = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(-180, 70),
                new DataPoint(30, 70)
        });
        lowThresh.setColor(Color.RED); // set color
        lowThresh.setDrawBackground(true);
        lowThresh.setBackgroundColor(Color.argb(100, 255, 0, 0));

        // hyper threshold
        LineGraphSeries<DataPoint> highThresh = new LineGraphSeries<>(new DataPoint[]{
                new DataPoint(-180, 240),
                new DataPoint(30, 240)
        });
        highThresh.setColor(Color.YELLOW);
        highThresh.setDrawBackground(true);
        highThresh.setBackgroundColor(Color.WHITE);

        // just for coloration purposes
        LineGraphSeries<DataPoint> forShading = new LineGraphSeries<>(new DataPoint[]{
                new DataPoint(-180, 400),
                new DataPoint(30, 400)
        });
        forShading.setColor(Color.TRANSPARENT);
        forShading.setDrawBackground(true);
        forShading.setBackgroundColor(Color.argb(50,255,255,0));

        // add to graph
        graph.addSeries(forShading);
        graph.addSeries(highThresh);
        graph.addSeries(lowThresh);

        // set up TIMED UPDATE for BG values on graph and in text
        predictedBG = new LineGraphSeries<>();
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.GREEN);
        paint.setStrokeWidth(10);
        paint.setPathEffect(new DashPathEffect(new float[]{8, 5}, 0));
        predictedBG.setCustomPaint(paint);

        graph.addSeries(predictedBG);

        measuredBG = new LineGraphSeries<>();
        measuredBG.setColor(Color.GREEN);

        graph.addSeries(measuredBG);

        // update regularly
        final Handler handlerE4 = new Handler();
        final Handler handlerBG = new Handler();
        final int delay = 300000; // ms, should be 300,000 for 5 mins

        timer = System.currentTimeMillis();
        // run every 5 min
        handlerBG.postDelayed(new Runnable() {
            @Override
            public void run() {

                // make volley requests for CGM data and then prediction (may need to go to one func)
                CGMjsonParse();
                predictionjsonParse();

                tracker_raw = 0;
                handlerE4.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        updateRaw();
                        handlerE4.postDelayed(this,9950); // ~10s delay

                    }
                }, 0);

                //
                if (tracker_avg!=0){
                    updateAvg();
                }

                // get most recent predicted BG and notify user if appropriate
                TextView predictionValue = findViewById(R.id.PredictionValue);
                int predictedBG = Integer.parseInt((String) predictionValue.getText());
//                int predictedHypo = Integer.parseInt((String) batteryLabel.getText());
                int predictedHypo =0;
                if(predictedBG<=70 || predictedHypo==1){
                    nManager.notify(0, nBuilder.build());
                }

                handlerBG.postDelayed(this, delay);
            }
        },0);

        //
    }

    // start of API querying funcs

    // Adapted from volley tutorial https://www.youtube.com/watch?v=y2xtLqP8dSQ
    // used for making the http request to Dexcom servers to get cgm data
    private void CGMjsonParse() {
        // url for request
        String url = String.format("https://sandbox-api.dexcom.com/v2/users/self/egvs?startDate=2017-06-15T15:%02d:00&endDate=2017-06-16T15:%02d:00",mn,mn);
//        Log.i("url",url);
        mn= mn+5;

        // access token for sandbox 1
        final String access_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IncyYUVpQmRlMXBfNnNjZmMzXzFpeHFvaDVqTSIsImtpZCI6IncyYUVpQmRlMXBfNnNjZmMzXzFpeHFvaDVqTSJ9.eyJpc3MiOiJodHRwczovL3VhbTEuZGV4Y29tLmNvbS9pZGVudGl0eSIsImF1ZCI6Imh0dHBzOi8vdWFtMS5kZXhjb20uY29tL2lkZW50aXR5L3Jlc291cmNlcyIsImV4cCI6MTYzODcyODc5NywibmJmIjoxNTQ0MTIwNzk3LCJjbGllbnRfaWQiOiJLYlNMcW5xcGJHRVdmR0xua1lwaWxPa2x1ak9FUVBTWSIsInNjb3BlIjpbImVndiIsImNhbGlicmF0aW9uIiwiZGV2aWNlIiwic3RhdGlzdGljcyIsImV2ZW50Iiwib2ZmbGluZV9hY2Nlc3MiXSwic3ViIjoiMDA3OGYzOTItYzJjOC00OTY5LWFjYjctMzllYThkNGM5ODhjIiwiYXV0aF90aW1lIjoxNTQ0MTIwNzg4LCJpZHAiOiJpZHNydiIsImp0aSI6ImFhZWM4OTNhMjM2M2NlOTM2M2VmNTAwY2U4MTdlNTFlIiwiYW1yIjpbInBhc3N3b3JkIl19.Q_TSDdz8qVBjj76nst6SRUlzB3FvaxqNuR_S1o-pFyZ1FsxBLhsJ9-nHAO-GmwW2drPHk9zf985YQcRNTrn3oZ2IvsPuO9bjEZkemtoD3gM5Dyf8lJGIVQXv19ht8j0roBCsVqroT3teol6RwHpPVbU8zGmHGdrcxFhh_xrLiVZ1IjcobqTJP-jsORZU_Vi1cGSNT1sOcDmWCJyJZ3Z81xdJgZaomZryvJJI4ZHDHkvURljFLLwgQHLsDquyiiAVBFNirZ14Qwhj2BYOyvIkoE5v0_bC_lLZgCKR9JMSM05qEQcKIedHGITW_wVykebrdyk_w7XfEhZHs8PY3Do7XA";

        JsonObjectRequest request = new JsonObjectRequest(com.android.volley.Request.Method.GET, url, null,
                new com.android.volley.Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("egvs");

                            List<Integer> measured = new ArrayList<>();
                            float[] cgm_readings = new float[jsonArray.length()];
                            for (int i=0; i< jsonArray.length(); i++) {
                                JSONObject egv_ = jsonArray.getJSONObject(i);

                                String trend = egv_.getString("trend");
                                int value = egv_.getInt("value");

                                cgm_readings[i] = (float) value;

                                if (i>jsonArray.length()-36){
                                    measured.add(value);
                                }

//                                BGButton.setText(""+jsonArray.length());
                            }

                            // update cgm features
                            cgm_feats[0] = cgm_readings[jsonArray.length()-1];
                            cgm_feats[1] = variance(cgm_readings);
                            float[] cgm_60 = Arrays.copyOfRange(cgm_readings,cgm_readings.length-12,cgm_readings.length);
                            float[] cgm_30 = Arrays.copyOfRange(cgm_readings,cgm_readings.length-6,cgm_readings.length);
                            cgm_feats[2] = maxValue(cgm_30)-cgm_30[cgm_30.length-1];
                            cgm_feats[3] = maxValue(cgm_60)-cgm_60[cgm_60.length-1];


                            // add to graph
                            measuredBG.resetData(plotMeasured(measured));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        ){
            // adapted from
            // https://stackoverflow.com/questions/17049473/how-to-set-custom-header-in-volley-request
            @Override
            public Map<String,String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("authorization", "Bearer " +access_token);

                return params;
            }
        };

        mQueue.add(request);

    }

    // Adapted from volley tutorial https://www.youtube.com/watch?v=y2xtLqP8dSQ
    // used for requesting my homemade api for predictions
    private void predictionjsonParse() {
        // url for request
        // update base when ngrok restarts

        // create random object to simulate inputs,

        ///////ONLY USED WHEN NO WATCH IS CONNECTED!!!!
        Random r = new Random();
        float i1 = (float) r.nextGaussian();
        float i2 = (float) r.nextGaussian();
        float i3 = (float) r.nextGaussian();
        float i4 = (float) r.nextGaussian();
        float i5 = (float) r.nextGaussian();
        float i6 = (float) r.nextGaussian();
        float i7 = (float) r.nextGaussian();
        float i8 = (float) r.nextGaussian();
        float i9 = (float) r.nextGaussian();


        float hr_si = 75;



        // predict w dummy data if no watch is connected
        String url = String.format("https://ccd57645.ngrok.io/predict?input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f",
                i1,i2,i3,i4,cgm_feats[2],i6,i7,i8,i9,cgm_feats[3],i3,i4,i5,i6,i7,i8,i9,i2,cgm_feats[1],i4,i5,i6,i7,i8,i9,cgm_feats[0]);


        if (e4_connected==1){

            updateFeats();
            url = String.format("https://ccd57645.ngrok.io/predict?input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f&input=%.2f",
                    hr_si,acc_feats[2],eda_feats[1],acc_feats[3],cgm_feats[2],hr_si,eda_feats[2],acc_feats[5],temp_feats[3],cgm_feats[3],eda_feats[60],acc_feats[1],eda_feats[0],hr_si,temp_feats[0],temp_feats[1],hr_si,acc_feats[0],cgm_feats[1],acc_feats[4],hr_si,hr_si,temp_feats[2],15,hr_si,cgm_feats[0]);
        }

        JsonObjectRequest request = new JsonObjectRequest(com.android.volley.Request.Method.GET, url, null,
                new com.android.volley.Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // get the prediction and set the prediction text to the prediction
                            int prediction = response.getInt("prediction");
                            PredictionValue = findViewById(R.id.PredictionValue);
                            PredictionValue.setText("" + prediction);
                            predictedBG.resetData(plotPrediction(prediction));
//                            testView.setText(prediction);

                            int is_hypo = response.getInt("hypo");
                            //hypoInd = findViewById(R.id.hypoInd);
                            // hackily pass hypo prediction
//                            batteryLabel = findViewById(R.id.battery_label);
//                            batteryLabel.setText(""+is_hypo);


                        } catch (JSONException e) {
                            e.printStackTrace();
//                            testView.setText("Nah");
                        }
                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        mQueue.add(request);

    }

    // graphing funcs
    public DataPoint[] plotPrediction(int predBG){
        // predicted BG being plotted

        DataPoint[] predictedBG = new DataPoint[2];
        //int predBG = (int) (160+Math.random()*80-40);
        int last_measured = Integer.parseInt((String) testView.getText());
        predictedBG[0] = new DataPoint(0,last_measured);
        predictedBG[1] = new DataPoint(30,predBG);

        return predictedBG;
    }

    public  DataPoint[] plotMeasured(List<Integer> mBG){
        // plot the measured BG values

        DataPoint[] measuredBG = new DataPoint[mBG.size()];

        for (int i=0; i< mBG.size(); i++) {
            measuredBG[i] = new DataPoint((-mBG.size()+i+1)*5, mBG.get(mBG.size()-i-1));
        }
        testView.setText("" + mBG.get(mBG.size()-1));
        testView.setVisibility(View.INVISIBLE);

        long newtime = System.currentTimeMillis();
        newtime = newtime-timer;
        Log.i("TIMER:", ""+ newtime);

        return measuredBG;

    }



    // notification
    private void createNotificationChannel(String CHANNEL_ID) {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name_low);
            String description = getString(R.string.channel_description_low);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    // update arrays for raw data
    private void updateRaw() {

        Button SettingsBtn = (Button) findViewById(R.id.Settings);


        String ibi_cur = (String) ibiLabel.getText();
        String temp_cur = (String) temperatureLabel.getText();
        String eda_cur = (String) edaLabel.getText();
        String accx_cur = (String) accel_xLabel.getText();
        String accy_cur = (String) accel_yLabel.getText();
        String accz_cur = (String) accel_zLabel.getText();

//        SettingsBtn.setText(""+temp_cur.equals("-")+eda_cur.equals("-")+accx_cur.equals("-"));
//        Log.i("ibi_issue", "ibi is:"+ibi_cur);

        if (tracker_raw<30 && !temp_cur.equals("-") && !eda_cur.equals("-") && !accx_cur.equals("-")) {
            // condition if receiving regulat ibi: !ibi_cur.isEmpty() && !ibi_cur.equals("-")
//            Log.i("ibi_issue2", "ibi is:"+ibi_cur);

            // get vals /put in holder
            hrs_raw[tracker_raw] = 75; // standin 1/Float.parseFloat(ibi_cur)*60
            temps_raw[tracker_raw] = Float.parseFloat(temp_cur);
            edas_raw[tracker_raw] = Float.parseFloat(eda_cur);

            float a_x = Float.parseFloat(accx_cur);
            float a_y = Float.parseFloat(accy_cur);
            float a_z = Float.parseFloat(accz_cur);
            double a_mag = Math.sqrt(a_x*a_x + a_y*a_y + a_z*a_z);
            accs_raw[tracker_raw] = (float) a_mag;

            BGButton.setText(tracker_raw + ":" + accs_raw[tracker_raw]);

            tracker_raw = tracker_raw+1;
        }
    }

    private void updateAvg(){
        edas_avg[tracker_avg] = mean(edas_raw);
        accs_avg[tracker_avg] = mean(accs_raw);
        temps_avg[tracker_avg] = mean(temps_raw);
        hrs_avg[tracker_avg] = 75; // standin

        // intiialize if no data exists, NOT IDEAL< WOULD BE REMOVED IF MORE TIME
        // this gives a weird burn in period
        if (tracker_avg==0){
            for (int j =1; j<288; j++){
                edas_avg[tracker_avg] = edas_avg[0];
                accs_avg[tracker_avg] = accs_avg[0];
                temps_avg[tracker_avg] = temps_avg[0];
                hrs_avg[tracker_avg] = 75; // standin
            }
        }

        tracker_avg = tracker_avg+1;
    }

    private void updateFeats(){
        eda_feats[0] = edas_avg[tracker_avg];
        eda_feats[1] = variance(edas_avg);
        float[] eda60 = Arrays.copyOfRange(edas_avg,276,288);
        float[] eda30 = Arrays.copyOfRange(edas_avg,282,288);
        eda_feats[2] = maxValue(eda30)-edas_avg[287];
        eda_feats[3] = maxValue(eda60)-edas_avg[287];

        // calc acc feats
        acc_feats[0] = accs_avg[tracker_avg];
//        float[] valid_acc = Arrays.copyOfRange(accs_avg,0,tracker_avg);
        float[] acc_hr = Arrays.copyOfRange(accs_avg,276,288);
        acc_feats[1] = mean(acc_hr);
        acc_hr = Arrays.copyOfRange(accs_avg,276,288);
        acc_feats[2] = mean(acc_hr);
        acc_hr = Arrays.copyOfRange(accs_avg,264,276);
        acc_feats[3] = mean(acc_hr);
        acc_hr = Arrays.copyOfRange(accs_avg,252,264);
        acc_feats[4] = mean(acc_hr);
        acc_hr = Arrays.copyOfRange(accs_avg,240,252);
        acc_feats[5] = mean(acc_hr);


        temp_feats[0] = temps_avg[tracker_avg];
//        float[] valid_temp = Arrays.copyOfRange(temps_avg,0,tracker_avg);
        temp_feats[1] = variance(temps_avg);
        float[] temp60 = Arrays.copyOfRange(temps_avg,276,288);
        float[] temp30 = Arrays.copyOfRange(temps_avg,282,288);
        temp_feats[2] = maxValue(temp30)-temps_avg[287];
        temp_feats[3] = maxValue(temp60)-temps_avg[287];
    }

    // variance
    // adapted from https://www.geeksforgeeks.org/program-for-variance-and-standard-deviation-of-an-array/
    static float variance(float a[])
    {
        // Compute mean (average of elements)
        int n = a.length;

        float mean_ = mean(a);

        // Compute sum squared
        // differences with mean.
        double sqDiff = 0;
        for (int i = 0; i < n; i++)
            sqDiff += (a[i] - mean_) *
                    (a[i] - mean_);

        return (float)sqDiff / n;
    }
    static float mean(float a[]){

        // Compute mean (average of elements)
        int n = a.length;
        float sum = 0;

        for (int i = 0; i < n; i++)
            sum += a[i];
        float mean = (float)sum / (float)n;

        return mean;
    }

    private static float maxValue(float[] arr) {
        float max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }

/// code here and below taken from e4 baseplate
    // what happens on startup
    private void initEmpaticaDeviceManager() {
        // Android 6 (API level 23) now require ACCESS_COARSE_LOCATION permission to use BLE
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.ACCESS_COARSE_LOCATION }, REQUEST_PERMISSION_ACCESS_COARSE_LOCATION);
        } else {

            if (TextUtils.isEmpty(EMPATICA_API_KEY)) {
                new AlertDialog.Builder(this)
                        .setTitle("Warning")
                        .setMessage("Please insert your API KEY")
                        .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // without permission exit is the only way
                                finish();
                            }
                        })
                        .show();
                return;
            }

            // Create a new EmpaDeviceManager. MainActivity is both its data and status delegate.
            deviceManager = new EmpaDeviceManager(getApplicationContext(), this, this);

            // Initialize the Device Manager using your API key. You need to have Internet access at this point.
            deviceManager.authenticateWithAPIKey(EMPATICA_API_KEY);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (deviceManager != null) {
            deviceManager.stopScanning();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (deviceManager != null) {
            deviceManager.cleanUp();
        }
    }

    // connect to device once discovered
    @Override
    public void didDiscoverDevice(EmpaticaDevice bluetoothDevice, String deviceName, int rssi, boolean allowed) {
        // Check if the discovered device can be used with your API key. If allowed is always false,
        // the device is not linked with your API key. Please check your developer area at
        // https://www.empatica.com/connect/developer.php
        if (allowed) {
            // Stop scanning. The first allowed device will do.
            deviceManager.stopScanning();
            try {
                // Connect to the device
                deviceManager.connectDevice(bluetoothDevice);
                updateLabel(deviceNameLabel, "To: " + deviceName);
            } catch (ConnectionNotAllowedException e) {
                // This should happen only if you try to connect when allowed == false.
                Toast.makeText(MainActivity.this, "Sorry, you can't connect to this device", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void didFailedScanning(int errorCode) {

    }

    // I guess if bluetooth isnt on, request user to turn it on
    @Override
    public void didRequestEnableBluetooth() {
        // Request the user to enable Bluetooth
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }

    @Override
    public void bluetoothStateChanged() {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // The user chose not to enable Bluetooth
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            // You should deal with this
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void didUpdateSensorStatus(@EmpaSensorStatus int status, EmpaSensorType type) {

        didUpdateOnWristStatus(status);
    }

    @Override
    public void didUpdateStatus(EmpaStatus status) {
        // Update the UI
        updateLabel(statusLabel, status.name());


        // The device manager is ready for use
        if (status == EmpaStatus.READY) {
            updateLabel(statusLabel, status.name() + " - Turn on your device");
            // Start scanning
            deviceManager.startScanning();
            // The device manager has established a connection

             hide();

        } else if (status == EmpaStatus.CONNECTED) {

            e4_connected=1;
            show();
            // The device manager disconnected from a device
        } else if (status == EmpaStatus.DISCONNECTED) {

            updateLabel(deviceNameLabel, "");

            hide();
        }
    }

    // handle acceleration
    @Override
    public void didReceiveAcceleration(int x, int y, int z, double timestamp) {
        updateLabel(accel_xLabel, "" + x);
        updateLabel(accel_yLabel, "" + y);
        updateLabel(accel_zLabel, "" + z);
    }

    @Override
    public void didReceiveBVP(float bvp, double timestamp) {
        updateLabel(bvpLabel, "" + bvp);
    }

    @Override
    public void didReceiveBatteryLevel(float battery, double timestamp) {
        //updateLabel(batteryLabel, String.format("%.0f %%", battery * 100));
    }

    @Override
    public void didReceiveGSR(float gsr, double timestamp) {
          updateLabel(edaLabel, "" + gsr);
    }

    @Override
    public void didReceiveIBI(float ibi, double timestamp) {
        updateLabel(ibiLabel, "" + ibi);
    }

    @Override
    public void didReceiveTemperature(float temp, double timestamp) {
        updateLabel(temperatureLabel, "" + temp);
    }

    // Update a label with some text, making sure this is run in the UI thread
    private void updateLabel(final TextView label, final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                label.setText(text);
            }
        });
    }

    @Override
    public void didReceiveTag(double timestamp) {

    }

    @Override
    public void didEstablishConnection() {

        show();
    }

    @Override
    public void didUpdateOnWristStatus(@EmpaSensorStatus final int status) {

        runOnUiThread(new Runnable() {

            @Override
            public void run() {

                if (status == EmpaSensorStatus.ON_WRIST) {

                    ((TextView) findViewById(R.id.wrist_status_label)).setText("ON WRIST");
                }
                else {

                    ((TextView) findViewById(R.id.wrist_status_label)).setText("NOT ON WRIST");
                }
            }
        });
    }

    void show() {

        runOnUiThread(new Runnable() {

            @Override
            public void run() {

                dataCnt.setVisibility(View.VISIBLE);
            }
        });
    }

    void hide() {

        runOnUiThread(new Runnable() {

            @Override
            public void run() {

                dataCnt.setVisibility(View.INVISIBLE);
            }
        });
    }
}
